document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.getElementById('hamburger-btn');
    const dropdown = document.getElementById('dropdown-content');
    const authDropdown = hamburger?.parentElement;

    if (hamburger && dropdown && authDropdown) {
        hamburger.addEventListener('click', function(e) {
            e.stopPropagation();
            authDropdown.classList.toggle('active');
        });
        document.addEventListener('click', function(e) {
            if (!authDropdown.contains(e.target)) {
                authDropdown.classList.remove('active');
            }
        });
    }

    document.querySelectorAll('.buku-populer-card').forEach(function(card) {
        card.addEventListener('mouseenter', function() {
            card.style.transform = 'scale(1.04)';
            card.style.boxShadow = '0 6px 24px rgba(37,99,235,0.13)';
        });
        card.addEventListener('mouseleave', function() {
            card.style.transform = '';
            card.style.boxShadow = '';
        });
    });
});
