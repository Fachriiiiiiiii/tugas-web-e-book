<footer>
    <div class="container-footer">
        <p>&copy; <?php echo date('Y'); ?> Fachri Fadlurrahman | SMK 2 Padang</p>
    </div>
</footer>
