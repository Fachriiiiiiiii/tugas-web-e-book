<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Book App</title>
    <link rel="stylesheet" href="/ebook-app/assets/css/style.css" />
    <script defer src="/ebook-app/assets/js/script.js"></script>
</head>
<body>
<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<header>
    <div class="container-header">
        <div class="header-flex">
            <div class="logo">
                <a href="/ebook-app/index.php"><strong>E-Book App</strong></a>
            </div>
            <nav class="nav-menu">
                <a href="/ebook-app/pages/home.php">Home</a>
                <a href="/ebook-app/pages/buku.php">Daftar Buku</a>
                <a href="/ebook-app/pages/dashboard.php">Dashboard</a>
                <a href="/ebook-app/pages/profile.php">Profil</a>
            </nav>
            <form class="search-form" action="/ebook-app/pages/buku.php" method="get">
                <input type="text" name="q" placeholder="Cari buku..." />
            </form>
            <a href="/ebook-app/pages/buku.php" class="btn-cari">Cari</a>
        </div>
        <div class="auth-dropdown">
            <button class="hamburger" id="hamburger-btn" aria-label="Menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <div class="dropdown-content" id="dropdown-content">
                <?php if (isset($_SESSION['username'])): ?>
                    <span class="auth-user">Halo, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <a href="/ebook-app/logout.php" class="btn-auth">Logout</a>
                <?php else: ?>
                    <a href="/ebook-app/login.php" class="btn-auth">Login</a>
                    <a href="/ebook-app/register.php" class="btn-auth">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>
</body>
</html>