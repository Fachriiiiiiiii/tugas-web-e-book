<?php
include 'include/header.php';
include 'include/koneksi.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $cek = mysqli_query($conn, "SELECT id FROM users WHERE username='$username' OR email='$email'");
    if (mysqli_num_rows($cek) > 0) {
        $error = "Username atau email sudah terdaftar!";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sss", $username, $email, $hash);
        if (mysqli_stmt_execute($stmt)) {
            $success = "Registrasi berhasil! Silakan login.";
        } else {
            $error = "Registrasi gagal!";
        }
        mysqli_stmt_close($stmt);
    }
}
?>
<main>
    <div class="container-register">
        <h2>Register</h2>
        <?php if ($error): ?>
            <div style="color:red; margin-bottom:1rem;"><?php echo $error; ?></div>
        <?php elseif ($success): ?>
            <div style="color:green; margin-bottom:1rem;"><?php echo $success; ?></div>
        <?php endif; ?>
        <form action="" method="post" class="register-form">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required />

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required />

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required />

            <button type="submit">Register</button>
        </form>
        <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
    </div>
</main>
<?php include 'include/footer.php'; ?>
