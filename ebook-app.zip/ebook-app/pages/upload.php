<?php
include '../include/header.php';
include '../include/koneksi.php';

if (!isset($_SESSION['username'])) {
    header("Location: /ebook-app/login.php");
    exit;
}

$edit = isset($_GET['edit']) ? intval($_GET['edit']) : 0;
$error = '';
$success = '';
$judul = $penulis = $deskripsi = '';
$cover = $file_pdf = '';

if ($edit) {
    $q = mysqli_query($conn, "SELECT * FROM buku WHERE id=$edit");
    $buku = mysqli_fetch_assoc($q);
    if ($buku) {
        $judul = $buku['judul'];
        $penulis = $buku['penulis'];
        $deskripsi = $buku['deskripsi'];
        $cover = $buku['cover'];
        $file_pdf = $buku['file_pdf'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = trim($_POST['judul']);
    $penulis = trim($_POST['penulis']);
    $deskripsi = trim($_POST['deskripsi']);

    if (isset($_FILES['cover']) && $_FILES['cover']['size'] > 0) {
        $cover_name = uniqid() . '_' . $_FILES['cover']['name'];
        $cover_tmp = $_FILES['cover']['tmp_name'];
        move_uploaded_file($cover_tmp, "../assets/img/" . $cover_name);
        if ($edit && $cover && file_exists("../assets/img/" . $cover)) {
            unlink("../assets/img/" . $cover);
        }
        $cover = $cover_name;
    }

    if (isset($_FILES['file_pdf']) && $_FILES['file_pdf']['size'] > 0) {
        $pdf_name = uniqid() . '_' . $_FILES['file_pdf']['name'];
        $pdf_tmp = $_FILES['file_pdf']['tmp_name'];
        move_uploaded_file($pdf_tmp, "../assets/pdf/" . $pdf_name);
        if ($edit && $file_pdf && file_exists("../assets/pdf/" . $file_pdf)) {
            unlink("../assets/pdf/" . $file_pdf);
        }
        $file_pdf = $pdf_name;
    }

    if ($edit) {
        $sql = "UPDATE buku SET judul=?, penulis=?, deskripsi=?, cover=?, file_pdf=? WHERE id=?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssssi", $judul, $penulis, $deskripsi, $cover, $file_pdf, $edit);
        if (mysqli_stmt_execute($stmt)) {
            $success = "Buku berhasil diperbarui!";
        } else {
            $error = "Gagal memperbarui buku!";
        }
        mysqli_stmt_close($stmt);
    } else {
        $sql = "INSERT INTO buku (judul, penulis, deskripsi, cover, file_pdf) VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssss", $judul, $penulis, $deskripsi, $cover, $file_pdf);
        if (mysqli_stmt_execute($stmt)) {
            $success = "Buku berhasil diupload!";
            $judul = $penulis = $deskripsi = $cover = $file_pdf = '';
        } else {
            $error = "Gagal upload buku!";
        }
        mysqli_stmt_close($stmt);
    }
}
?>
<main>
    <div class="container-upload">
        <h2><?php echo $edit ? 'Edit Buku' : 'Upload Buku Baru'; ?></h2>
        <?php if ($error): ?>
            <div style="color:red; margin-bottom:1rem;"><?php echo $error; ?></div>
        <?php elseif ($success): ?>
            <div style="color:green; margin-bottom:1rem;"><?php echo $success; ?></div>
        <?php endif; ?>
        <form action="" method="post" enctype="multipart/form-data" class="upload-form">
            <label for="judul">Judul Buku</label>
            <input type="text" id="judul" name="judul" value="<?php echo htmlspecialchars($judul); ?>" required />

            <label for="penulis">Penulis</label>
            <input type="text" id="penulis" name="penulis" value="<?php echo htmlspecialchars($penulis); ?>" required />

            <label for="deskripsi">Deskripsi</label>
            <textarea id="deskripsi" name="deskripsi" rows="4" required><?php echo htmlspecialchars($deskripsi); ?></textarea>

            <label for="cover">Cover Buku <?php if ($cover): ?><br><img src="../assets/img/<?php echo $cover; ?>" alt="cover" style="width:60px; margin-top:5px;"><?php endif; ?></label>
            <input type="file" id="cover" name="cover" accept="image/*" />

            <label for="file_pdf">File PDF <?php if ($file_pdf): ?><br><a href="../assets/pdf/<?php echo $file_pdf; ?>" target="_blank">Lihat PDF</a><?php endif; ?></label>
            <input type="file" id="file_pdf" name="file_pdf" accept="application/pdf" />

            <button type="submit"><?php echo $edit ? 'Update' : 'Upload'; ?></button>
        </form>
    </div>
</main>
<?php include '../include/footer.php'; ?>
