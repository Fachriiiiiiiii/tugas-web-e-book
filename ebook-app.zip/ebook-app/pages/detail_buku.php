<?php
include '../include/header.php';
include '../include/koneksi.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$sql = "SELECT * FROM buku WHERE id = $id";
$result = mysqli_query($conn, $sql);
$buku = mysqli_fetch_assoc($result);
?>
<main>
    <div class="container-detail-buku">
        <?php if ($buku): ?>
            <div class="detail-buku-card">
                <img src="../assets/img/<?php echo $buku['cover'] ?: 'default-cover.png'; ?>" alt="<?php echo htmlspecialchars($buku['judul']); ?>" class="cover-detail-buku" />
                <div class="detail-info">
                    <h2><?php echo htmlspecialchars($buku['judul']); ?></h2>
                    <p><strong>Penulis:</strong> <?php echo htmlspecialchars($buku['penulis']); ?></p>
                    <p><strong>Deskripsi:</strong><br><?php echo nl2br(htmlspecialchars($buku['deskripsi'])); ?></p>
                </div>
            </div>
        <?php else: ?>
            <p>Buku tidak ditemukan.</p>
        <?php endif; ?>
    </div>
</main>
<?php include '../include/footer.php'; ?>
