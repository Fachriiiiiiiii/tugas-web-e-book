<?php
include '../include/header.php';
include '../include/koneksi.php';

$q_buku = mysqli_query($conn, "SELECT id FROM buku");
$total_buku = ($q_buku) ? mysqli_num_rows($q_buku) : 0;

$q_pdf = mysqli_query($conn, "SELECT id FROM buku WHERE file_pdf IS NOT NULL AND file_pdf != ''");
$total_pdf = ($q_pdf) ? mysqli_num_rows($q_pdf) : 0;

$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest';
?>
<main>
    <div class="container-profile">
        <div class="profile-card">
            <img src="../assets/img/avatar-default.png" alt="Avatar" class="profile-avatar" />
            <h2>Fachri Fadlurrahman</h2>
            <p>SMK 2 Padang</p>
            <p>Email: fachri@email.com</p>
            <div class="profile-user-info" style="margin:1rem 0;">
                <span style="color:#2563EB;font-weight:500;">Login sebagai: <?php echo htmlspecialchars($username); ?></span>
            </div>
            <div class="profile-stats">
                <div>
                    <span class="profile-stat-label">Total Buku</span>
                    <span class="profile-stat-value"><?php echo $total_buku; ?></span>
                </div>
                <div>
                    <span class="profile-stat-label">Buku PDF</span>
                    <span class="profile-stat-value"><?php echo $total_pdf; ?></span>
                </div>
            </div>
            <div class="profile-about">
                <h3>Tentang Saya</h3>
                <p>Siswa SMK 2 Padang yang suka teknologi dan pengembangan aplikasi web. Ingin membuat perpustakaan digital yang modern dan mudah digunakan.</p>
            </div>
            <?php if (!$q_buku || !$q_pdf): ?>
                <div style="color:red; margin-top:1rem;">Gagal mengambil data statistik buku.</div>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php include '../include/footer.php'; ?>