<?php
include '../include/header.php';
?>
<main>
    <div class="container-home">
        <h1>Selamat Datang di E-Book App</h1>
        <p>
            Aplikasi perpustakaan digital sederhana untuk membaca dan mengelola koleksi buku secara online.<br>
            Temukan berbagai buku menarik dan nikmati kemudahan akses di mana saja!
        </p>
        <a href="buku.php" class="btn-lihat-buku">Lihat Daftar Buku</a>
        <div class="home-section">
            <h2>Visi</h2>
            <p>
                Menjadi platform perpustakaan digital modern yang mudah diakses, mendukung literasi, dan memudahkan siswa serta guru dalam mencari dan membaca buku di era digital.
            </p>
        </div>
        <div class="home-section">
            <h2>Misi</h2>
            <ul>
                <li>Menyediakan koleksi buku digital yang lengkap dan mudah diakses.</li>
                <li>Mendukung pembelajaran mandiri dan kolaboratif di lingkungan sekolah.</li>
                <li>Mendorong minat baca siswa melalui teknologi.</li>
                <li>Memberikan kemudahan pengelolaan koleksi buku bagi admin dan pustakawan.</li>
            </ul>
        </div>
        <div class="home-section">
            <h2>Tentang Website</h2>
            <p>
                E-Book App adalah aplikasi perpustakaan digital berbasis web yang dikembangkan untuk memudahkan akses buku secara online di lingkungan sekolah. Dengan tampilan modern dan fitur CRUD buku, aplikasi ini cocok untuk tugas sekolah maupun kebutuhan perpustakaan digital skala kecil.
            </p>
        </div>
        <div class="home-section">
            <h2>Kontak</h2>
            <p>
                Developer: Fachri Fadlurrahman<br>
                Sekolah: SMK 2 Padang<br>
                Email: fachri@email.com
            </p>
        </div>
    </div>
</main>
<?php include '../include/footer.php'; ?>
