<?php
include '../include/header.php';
include '../include/koneksi.php';

if (!isset($_SESSION['username'])) {
    header("Location: /ebook-app/login.php");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $q = mysqli_query($conn, "SELECT cover, file_pdf FROM buku WHERE id=$id");
    $buku = mysqli_fetch_assoc($q);
    if ($buku) {
        if (!empty($buku['cover']) && file_exists("../assets/img/" . $buku['cover'])) {
            unlink("../assets/img/" . $buku['cover']);
        }
        if (!empty($buku['file_pdf']) && file_exists("../assets/pdf/" . $buku['file_pdf'])) {
            unlink("../assets/pdf/" . $buku['file_pdf']);
        }
    }
    mysqli_query($conn, "DELETE FROM buku WHERE id=$id");
    header("Location: dashboard.php");
    exit;
}

$q_total_buku = mysqli_query($conn, "SELECT COUNT(*) as total FROM buku");
$total_buku = ($q_total_buku && $row = mysqli_fetch_assoc($q_total_buku)) ? $row['total'] : 0;

$q_total_pdf = mysqli_query($conn, "SELECT COUNT(*) as total FROM buku WHERE file_pdf IS NOT NULL AND file_pdf != ''");
$total_pdf = ($q_total_pdf && $row = mysqli_fetch_assoc($q_total_pdf)) ? $row['total'] : 0;

$q_total_user = mysqli_query($conn, "SELECT COUNT(*) as total FROM users");
$total_user = ($q_total_user && $row = mysqli_fetch_assoc($q_total_user)) ? $row['total'] : 0;

$user = isset($_SESSION['username']) ? $_SESSION['username'] : '-';

$result = mysqli_query($conn, "SELECT * FROM buku ORDER BY id DESC");
?>
<main>
    <div class="container-dashboard">
        <h2>Dashboard</h2>
        <div class="dashboard-stats" style="display:flex; gap:2rem; margin-bottom:2rem; flex-wrap:wrap;">
            <div class="dashboard-card">
                <h3>Total Buku</h3>
                <p><?php echo $total_buku; ?></p>
            </div>
            <div class="dashboard-card">
                <h3>Buku dengan PDF</h3>
                <p><?php echo $total_pdf; ?></p>
            </div>
            <div class="dashboard-card">
                <h3>Total Pengguna</h3>
                <p><?php echo $total_user; ?></p>
            </div>
            <div class="dashboard-card">
                <h3>User Login</h3>
                <p><?php echo htmlspecialchars($user); ?></p>
            </div>
        </div>
        <div class="dashboard-quickaction" style="margin-bottom:2rem;">
            <a href="upload.php" class="btn-lihat-buku" style="margin-right:1rem;">+ Upload Buku Baru</a>
            <a href="buku.php" class="btn-lihat-buku" style="background:#6B7280;">Lihat Semua Buku</a>
        </div>
        <div class="dashboard-welcome" style="margin-bottom:2rem;">
            <p>Selamat datang di <b>E-Book App</b>! Kelola koleksi buku digital sekolahmu dengan mudah.<br>
            Gunakan menu di atas atau tombol di bawah ini untuk menambah, mengedit, atau menghapus buku.</p>
        </div>
        <div class="dashboard-info">
            <table style="width:100%; background:#fff; border-radius:10px; box-shadow:0 2px 12px rgba(37,99,235,0.07); overflow:hidden;">
                <thead style="background:#F3F4F6;">
                    <tr>
                        <th style="padding:10px;">Cover</th>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>PDF</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td style="text-align:center;">
                            <img src="../assets/img/<?php echo $row['cover'] ?: 'default-cover.png'; ?>" alt="cover" style="width:50px; height:70px; object-fit:cover; border-radius:4px;">
                        </td>
                        <td><?php echo htmlspecialchars($row['judul']); ?></td>
                        <td><?php echo htmlspecialchars($row['penulis']); ?></td>
                        <td>
                            <?php if (!empty($row['file_pdf'])): ?>
                                <a href="../assets/pdf/<?php echo $row['file_pdf']; ?>" target="_blank">Lihat PDF</a>
                            <?php else: ?>
                                <span style="color:#aaa;">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="detail_buku.php?id=<?php echo $row['id']; ?>" class="btn-auth" style="padding:0.2rem 0.7rem;">Detail</a>
                            <a href="upload.php?edit=<?php echo $row['id']; ?>" class="btn-auth" style="padding:0.2rem 0.7rem;">Edit</a>
                            <a href="dashboard.php?hapus=<?php echo $row['id']; ?>" class="btn-auth" style="padding:0.2rem 0.7rem; background:#ef4444;" onclick="return confirm('Yakin hapus buku ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<?php include '../include/footer.php'; ?>
