<?php
include '../include/header.php';
include '../include/koneksi.php';

$q = isset($_GET['q']) ? mysqli_real_escape_string($conn, $_GET['q']) : '';

$populer = mysqli_query($conn, "SELECT * FROM buku ORDER BY id DESC LIMIT 3");

$total_buku = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM buku"));

$sql = "SELECT * FROM buku";
if ($q != '') {
    $sql .= " WHERE judul LIKE '%$q%'";
}
$sql .= " ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>
<main>
    <div class="container-buku">
        <div class="buku-banner-motivasi">
            <h2>📚 Temukan Buku Favoritmu!</h2>
            <p>Perbanyak wawasan, tingkatkan literasi, dan jadikan membaca sebagai gaya hidup modern.</p>
        </div>
        <div class="buku-kategori-section">
            <span class="buku-kategori">Fiksi</span>
            <span class="buku-kategori">Non-Fiksi</span>
            <span class="buku-kategori">Pelajaran</span>
            <span class="buku-kategori">Lainnya</span>
        </div>
        <h2>Daftar Buku</h2>
        <div class="buku-info-summary">
            <span>Total Buku: <b><?php echo $total_buku; ?></b></span>
            <?php if ($q != ''): ?>
                <span>Hasil pencarian untuk: <strong><?php echo htmlspecialchars($q); ?></strong></span>
            <?php endif; ?>
        </div>
        <div class="buku-populer-section">
            <h3>Buku Terpopuler</h3>
            <div class="buku-populer-list">
                <?php while($pop = mysqli_fetch_assoc($populer)): ?>
                    <div class="buku-populer-card">
                        <img src="../assets/img/<?php echo $pop['cover'] ?: 'default-cover.png'; ?>" alt="<?php echo htmlspecialchars($pop['judul']); ?>" class="cover-buku-populer" />
                        <div>
                            <div class="judul-populer"><?php echo htmlspecialchars($pop['judul']); ?></div>
                            <div class="penulis-populer">Penulis: <?php echo htmlspecialchars($pop['penulis']); ?></div>
                            <a href="detail_buku.php?id=<?php echo $pop['id']; ?>" class="btn-populer-detail">Detail</a>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
        <div class="list-buku">
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <div class="buku-card">
                        <a href="detail_buku.php?id=<?php echo $row['id']; ?>">
                            <img src="../assets/img/<?php echo $row['cover'] ?: 'default-cover.png'; ?>" alt="<?php echo htmlspecialchars($row['judul']); ?>" class="cover-buku" />
                            <h3><?php echo htmlspecialchars($row['judul']); ?></h3>
                            <p>Penulis: <?php echo htmlspecialchars($row['penulis']); ?></p>
                        </a>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="buku-empty">
                    <svg width="120" height="120" viewBox="0 0 120 120" fill="none">
                        <rect x="20" y="40" width="80" height="50" rx="8" fill="#F3F4F6"/>
                        <rect x="30" y="50" width="60" height="30" rx="4" fill="#2563EB" fill-opacity="0.15"/>
                        <rect x="40" y="60" width="40" height="10" rx="2" fill="#2563EB" fill-opacity="0.25"/>
                        <rect x="50" y="75" width="20" height="4" rx="2" fill="#2563EB" fill-opacity="0.25"/>
                    </svg>
                    <p>Tidak ada buku ditemukan.<br>Yuk upload buku baru!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php include '../include/footer.php'; ?>
