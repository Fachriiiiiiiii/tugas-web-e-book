<?php
include 'include/header.php';
include 'include/koneksi.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = mysqli_prepare($conn, "SELECT id, username, password FROM users WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) > 0) {
        mysqli_stmt_bind_result($stmt, $id, $user, $hash);
        mysqli_stmt_fetch($stmt);
        if (password_verify($password, $hash)) {
            $_SESSION['username'] = $user;
            $_SESSION['user_id'] = $id;
            header("Location: pages/home.php");
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak ditemukan!";
    }
    mysqli_stmt_close($stmt);
}
?>
<main>
    <div class="container-login">
        <h2>Login</h2>
        <?php if ($error): ?>
            <div style="color:red; margin-bottom:1rem;"><?php echo $error; ?></div>
        <?php endif; ?>
        <form action="" method="post" class="login-form">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required />

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required />

            <button type="submit">Login</button>
        </form>
        <p>Belum punya akun? <a href="register.php">Daftar di sini</a></p>
    </div>
</main>
<?php include 'include/footer.php'; ?>
